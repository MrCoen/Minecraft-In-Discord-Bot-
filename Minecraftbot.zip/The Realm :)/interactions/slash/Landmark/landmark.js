const fs = require("fs");
const path = require("path");
const { SlashCommandBuilder, EmbedBuilder, messageLink } = require("discord.js");

// Define the path to the JSON file where setup data will be stored
const landmarkdata = path.resolve(__dirname, "../../../data/landmarks.json");

// Base coordinates
const baseCoordinates = { x: 950, y: 110, z: 1120 };

function readLandmarks() {
	try {
		const data = fs.readFileSync(landmarkdata, "utf8");
		return data ? JSON.parse(data) : { landmarks: {} };
	} catch (error) {
		if (error.code === "ENOENT") {
			return { landmarks: {} };
		} else {
			throw error;
		}
	}
}

function writeLandmarks(landmarks) {
	const data = JSON.stringify(landmarks, null, 2);
	fs.writeFileSync(landmarkdata, data, "utf8");
}

function addLandmark(type, name, x, y, z, description, timestamp, user) {
	const landmarks = readLandmarks();

	if (!landmarks.landmarks[type]) {
		landmarks.landmarks[type] = [];
	}

	const newLandmark = {
		name: name,
		coordinates: { x, y, z },
		metadata: { description, timestamp, user },
	};

	landmarks.landmarks[type].push(newLandmark);
	writeLandmarks(landmarks);
}

function calculateDistance(coord1, coord2) {
	return Math.sqrt(
		Math.pow(coord2.x - coord1.x, 2) +
			Math.pow(coord2.y - coord1.y, 2) +
			Math.pow(coord2.z - coord1.z, 2),
	);
}

module.exports = {
	data: new SlashCommandBuilder()
		.setName("landmarks")
		.setDescription("Manage landmarks within The Real :)")
		.addSubcommand((subcommand) =>
			subcommand
				.setName("add")
				.setDescription("Add a landmark that you have found on the map.")
				.addStringOption((option) =>
					option
						.setName("landmark")
						.setDescription("Select the landmark")
						.setRequired(true)
						.addChoices(
							{ name: "Spider Spawner", value: "spider_spawner" },
							{ name: "Skeleton Spawner", value: "skeleton_spawner" },
							{ name: "Zombie Spawner", value: "zombie_spawner" },
							{ name: "Amethyst Geode", value: "amethyst_geode" },
							{ name: "Ancient City", value: "ancient_city" },
							{ name: "Village", value: "village" },
							{ name: "Desert Pyramid", value: "desert_pyramid" },
							{ name: "Jungle Pyramid", value: "jungle_pyramid" },
							{ name: "Nether Fortress", value: "nether_fortress" },
							{ name: "Ocean Monument", value: "ocean_monument" },
							{ name: "Stronghold", value: "stronghold" },
							{ name: "Woodland Mansion", value: "woodland_mansion" },
						),
				)
				.addStringOption((option) =>
					option
						.setName("description")
						.setDescription(
							"Additional information about the landmark ",
						)
						.setRequired(true),
				)
				.addIntegerOption((option) =>
					option
						.setName("xcoordinate")
						.setDescription("Tell us the x Co-ordinate")
						.setRequired(true),
				)
				.addIntegerOption((option) =>
					option
						.setName("ycoordinate")
						.setDescription("Tell us the Y Co-ordinate")
						.setRequired(true),
				)
				.addIntegerOption((option) =>
					option
						.setName("zcoordinate")
						.setDescription("Tell us the Z Co-ordinate")
						.setRequired(true),
				),
		)
		.addSubcommand((subcommand) =>
			subcommand
				.setName("search")
				.setDescription("Search for landmarks closest to base.")
				.addStringOption((option) =>
					option
						.setName("landmark")
						.setDescription("Select the landmark type")
						.setRequired(true)
						.addChoices(
							{ name: "Spider Spawner", value: "spider_spawner" },
							{ name: "Skeleton Spawner", value: "skeleton_spawner" },
							{ name: "Zombie Spawner", value: "zombie_spawner" },
							{ name: "Amethyst Geode", value: "amethyst_geode" },
							{ name: "Ancient City", value: "ancient_city" },
							{ name: "Village", value: "village" },
							{ name: "Desert Pyramid", value: "desert_pyramid" },
							{ name: "Jungle Pyramid", value: "jungle_pyramid" },
							{ name: "Nether Fortress", value: "nether_fortress" },
							{ name: "Ocean Monument", value: "ocean_monument" },
							{ name: "Stronghold", value: "stronghold" },
							{ name: "Woodland Mansion", value: "woodland_mansion" },
						),
				),
		),

	async execute(interaction) {
		if (interaction.options.getSubcommand() === "add") {
			const landmark = interaction.options.getString("landmark");
			const x = interaction.options.getInteger("xcoordinate");
			const y = interaction.options.getInteger("ycoordinate");
			const z = interaction.options.getInteger("zcoordinate");
			const landmarkDescription = interaction.options.getString("description");
			const timestamp = new Date().toISOString();
			let user = interaction.user.username

			addLandmark(landmark, landmark, x, y, z, landmarkDescription, timestamp, user);
			await interaction.reply(`Landmark ${landmark} added successfully!`);
		} else if (interaction.options.getSubcommand() === "search") {
			const landmarkType = interaction.options.getString("landmark");
			const landmarksData = readLandmarks();

			if (
				!landmarksData.landmarks[landmarkType] ||
				landmarksData.landmarks[landmarkType].length === 0
			) {
				await interaction.reply(`No landmarks found for type: ${landmarkType}`);
				return;
			}

			const sortedLandmarks = landmarksData.landmarks[landmarkType].sort(
				(a, b) => {
					const distanceA = calculateDistance(baseCoordinates, a.coordinates);
					const distanceB = calculateDistance(baseCoordinates, b.coordinates);
					return distanceA - distanceB;
				},
			);

			const closestLandmarks = sortedLandmarks.slice(0, 6);
			const landmarkembed = new EmbedBuilder().setColor("#eee600");
			const replyMessage = closestLandmarks
				.map((landmark, index) => {
					const distance = calculateDistance(
						baseCoordinates,
						landmark.coordinates,
					).toFixed(2);
					landmarkembed.setAuthor({ name: interaction.user.username + `'s Request`, iconURL: 'https://external-content.duckduckgo.com/iu/?u=https%3A%2F%2Fclipartcraft.com%2Fimages%2Fminecraft-logo-png-2.png&f=1&nofb=1&ipt=76833f8b5d0a3936330b023f7b6c50026b8025c559bb6dca7711634e5e652219&ipo=images' })
					return landmarkembed.addFields({
						name: '#' + landmark.name + ` ${index + 1}`,
						value:
							`Coordinates: (***${landmark.coordinates.x}, ${landmark.coordinates.y}, ${landmark.coordinates.z}***)\n` +
							`Description: ***${landmark.metadata.description}***\n` +
							`Distance to base: ***${distance} blocks***\n` + 
							`Found By: ***${landmark.metadata.user}***`,
						inline: true,
					});

					// `**${index + 1}. ${landmark.name}**\n` +
					// 	`Coordinates: (${landmark.coordinates.x}, ${landmark.coordinates.y}, ${landmark.coordinates.z})\n` +
					// 	`Description: ${landmark.metadata.description}\n` +
					// 	`Distance to base: ${distance} blocks\n`;
				})
				.join("\n");

			await interaction.reply({
				embeds:
					[landmarkembed] || `No landmarks found for type: ${landmarkType}`,
			});
		}
	},
};
