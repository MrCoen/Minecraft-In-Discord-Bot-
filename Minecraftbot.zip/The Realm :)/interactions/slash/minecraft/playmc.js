const fs = require("fs");
const path = require("path");
const { SlashCommandBuilder, EmbedBuilder } = require("discord.js");
const { v4: uuidv4 } = require("uuid");

// Define the path to the JSON file where setup data will be stored
const UserData = path.resolve(__dirname, "../../../data/minecraftuser.json");

// Base coordinates
const baseCoordinates = { x: 950, y: 110, z: 1120 };

// List of available biomes
const biomes = [
	"Forest",
	"Plains",
	"Desert",
	"Taiga",
	"Savanna",
	"Snowy Tundra",
	"Jungle",
	"Swamp",
	"Mesa",
	"Mushroom Fields",
];

// List of structures with associated discovery probabilities
const structures = [
	{ name: "Village", probability: 0.25 },
	{ name: "Desert Pyramid", probability: 0.1 },
	{ name: "Jungle Temple", probability: 0.05 },
	{ name: "Stronghold", probability: 0.03 },
	{ name: "Mineshaft", probability: 0.15 },
	{ name: "Ocean Monument", probability: 0.05 },
	{ name: "Woodland Mansion", probability: 0.02 },
	{ name: "Nether Fortress", probability: 0.1 },
	{ name: "End City", probability: 0.01 },
];

// List of rare items
const rareItems = [
	{ name: "Diamond", id: "diamond", amount: 1, price: 100 },
	{ name: "Netherite Ingot", id: "netherite_ingot", amount: 1, price: 500 },
	{name: "Enchanted Golden Apple", id: "enchanted_golden_apple",amount: 1,price: 200,},
	{ name: "Totem of Undying", id: "totem_of_undying", amount: 1, price: 250 },
	{ name: "Emerald", id: "emerald", amount: 1, price: 50 },
	{ name: "Golden Apple", id: "golden_apple", amount: 1, price: 20 },
	{ name: "Potion of Healing", id: "potion_of_healing", amount: 1, price: 15 },
	{ name: "Ender Pearl", id: "ender_pearl", amount: 1, price: 30 },
	{ name: "Blaze Rod", id: "blaze_rod", amount: 1, price: 40 },
];

// Define prices for mineable items
const itemPrices = {
    cobblestone: 1,
    andesite: 2,
    granite: 2,
    diorite: 2,
    deepslate: 3,
    lapiz: 15,
    gold: 25,
    copper: 20,
    diamond: 100,
    netherite_ingot: 500,
    enchanted_golden_apple: 200,
    totem_of_undying: 250,
    emerald: 50,
    golden_apple: 20,
    potion_of_healing: 15,
    ender_pearl: 30,
    blaze_rod: 40,
};


function readUsers() {
	try {
		const data = fs.readFileSync(UserData, "utf8");
		return data ? JSON.parse(data) : { mcuser: {} };
	} catch (error) {
		if (error.code === "ENOENT") {
			return { mcuser: {} };
		} else {
			throw error;
		}
	}
}

function writeUser(mcusers) {
	const data = JSON.stringify(mcusers, null, 2);
	fs.writeFileSync(UserData, data, "utf8");
}

function generateUniqueCoordinates(existingUsers) {
	let x, y, z;
	let isUnique = false;

	while (!isUnique) {
		// Generate random coordinates
		x = Math.floor(Math.random() * 2000) - 1000; // Example range: -1000 to 1000
		y = Math.floor(Math.random() * 200) + 50; // Example range: 50 to 250 (ensuring it's above ground level)
		z = Math.floor(Math.random() * 2000) - 1000; // Example range: -1000 to 1000

		// Check if these coordinates are unique
		isUnique = !Object.values(existingUsers).some(
			(user) =>
				user.coordinates.x === x &&
				user.coordinates.y === y &&
				user.coordinates.z === z,
		);
	}

	return { x, y, z };
}

function getRandomBiome() {
	return biomes[Math.floor(Math.random() * biomes.length)];
}

function getRandomStructure() {
	const random = Math.random();
	let cumulativeProbability = 0;

	for (const structure of structures) {
		cumulativeProbability += structure.probability;
		if (random < cumulativeProbability) {
			return structure.name;
		}
	}

	return null; // No structure found
}

function getRandomRareItems() {
	const numberOfItems = Math.floor(Math.random() * 3) + 1; // 1 to 3 items
	const selectedItems = [];
	for (let i = 0; i < numberOfItems; i++) {
		selectedItems.push(rareItems[Math.floor(Math.random() * rareItems.length)]);
	}
	return selectedItems;
}

function addUser(discordId, name, description, timestamp) {
	const userinformation = readUsers();

	// Check if the user is already part of the game
	if (userinformation.mcuser[discordId]) {
		throw new Error("User is already part of the game.");
	}

	const id = uuidv4(); // Generate a unique ID using uuid
	const { x, y, z } = generateUniqueCoordinates(userinformation.mcuser);
	const biome = getRandomBiome();

	const mcUser = {
		name: name,
		id: id,
		discordId: discordId,
		pfplink: 'https://cdn.discordapp.com/avatars/1267912619478483026/36c100f3f978aa5c6d752da207a28d89.png',
		coordinates: { x, y, z },
		biome: biome,
		inventory: {},
		mining: {
			startTime: null,
			duration: 0,
		},
	};

	userinformation.mcuser[discordId] = mcUser;
	writeUser(userinformation);
}

function exploreUser(discordId) {
	const userinformation = readUsers();
	const user = userinformation.mcuser[discordId];
	if (!user) {
		throw new Error("User not found.");
	}

	const { x, y, z } = generateUniqueCoordinates(userinformation.mcuser);
	const newBiome = getRandomBiome();
	const foundStructure = Math.random() < 0.1; // 10% chance to find a structure
	const newStructure = foundStructure ? getRandomStructure() : null;

	user.coordinates = { x, y, z };
	user.biome = newBiome;

	let message = `You have discovered a new biome: **${newBiome}** at coordinates (${x}, ${y}, ${z}).`;

	if (foundStructure && newStructure) {
		message += ` You also found a **${newStructure}**!`;
		const rareItemsFound = getRandomRareItems();
		const itemMessages = rareItemsFound
			.map((item) => {
				if (!user.inventory[item.id]) {
					user.inventory[item.id] = { ...item, amount: 0 };
				}
				user.inventory[item.id].amount += item.amount;
				return `**${item.amount}x ${item.name}**`;
			})
			.join(", ");
		message += ` In a chest, you found: ${itemMessages}.`;
	}

	writeUser(userinformation);
	return { message };
}

function getUserInventory(discordId) {
	const userinformation = readUsers();
	const user = userinformation.mcuser[discordId];
	if (!user) {
		throw new Error("User not found.");
	}

	const inventoryItems = Object.values(user.inventory)
		.filter((item) => item.amount > 0)
		.map((item) => `**${item.amount}x ${item.name}**`)
		.join("\n");

	return inventoryItems || "Your inventory is empty.";
}

function startMining(discordId, duration, interaction) {
	const userinformation = readUsers();
	const user = userinformation.mcuser[discordId];
	if (!user) {
		return `Mining not started, you are not part of the game do ` + "`/minecraft start`";
	}

	if (user.mining.startTime) {
		throw new Error("You are already mining.");
	}

	const now = Date.now();
	user.mining = {
		startTime: now,
		duration: duration * 1000, // Convert to milliseconds
	};

	writeUser(userinformation);

	// Schedule a message to be sent after mining is complete
	setTimeout(() => {
		completeMining(discordId, interaction);
	}, duration * 1000);

	return `Mining started! You will return with your ores in ${duration} seconds.`;
}

function completeMining(discordId, interaction) {
	const userinformation = readUsers();
	const user = userinformation.mcuser[discordId];
	if (!user || !user.mining.startTime) {
		interaction.followUp("You are not mining currently.");
		return;
	}

	const now = Date.now();
	const timeElapsed = now - user.mining.startTime;
	if (timeElapsed < user.mining.duration) {
		interaction.followUp("Your mining session is not yet complete.");
		return;
	}

	user.mining.startTime = null;

	// Add mined items to inventory
	const minedItems = {
		cobblestone: Math.floor(Math.random() * 100) + 1,
		andesite: Math.floor(Math.random() * 50),
		granite: Math.floor(Math.random() * 50),
		diorite: Math.floor(Math.random() * 50),
		deepslate: Math.floor(Math.random() * 30),
		diamond: Math.floor(Math.random() * 5),
		gold: Math.floor(Math.random() * 10),
		copper: Math.floor(Math.random() * 20),
		lapiz: Math.floor(Math.random() * 8)
	};

	for (const [item, amount] of Object.entries(minedItems)) {
		if (!user.inventory[item]) {
			user.inventory[item] = {
				name: item.charAt(0).toUpperCase() + item.slice(1),
				blockid: item,
				amount: 0,
			};
		}
		user.inventory[item].amount += amount;
	}

	writeUser(userinformation);

	const minedItemsMessage = Object.entries(minedItems)
		.map(
			([item, amount]) =>
				`**${amount}x ${item.charAt(0).toUpperCase() + item.slice(1)}**`,
		)
		.join(", ");

	interaction.editReply(
		`Mining session complete! You have mined: ${minedItemsMessage}.`,
	);
}

function sellItem(discordId, itemId, amount) {
	const userinformation = readUsers();
	const user = userinformation.mcuser[discordId];
	if (!user) {
		throw new Error("User not found.");
	}

	const item = user.inventory[itemId];
	if (!item || item.amount < amount) {
		throw new Error("You do not have enough of this item to sell.");
	}

	const price = itemPrices[itemId];
	if (!price) {
		throw new Error("This item cannot be sold.");
	}

	item.amount -= amount;
	const totalPrice = price * amount;

	if (!user.balance) {
		user.balance = 0;
	}
	user.balance += totalPrice;

	writeUser(userinformation);

	return `You have sold ${amount}x ${item.name} for ${totalPrice} coins. Your new balance is ${user.balance} coins.`;
}

function calculateNetWorth(inventory) {
    let netWorth = 0;
    for (const itemId in inventory) {
        if (itemPrices[itemId]) {
            netWorth += inventory[itemId].amount * itemPrices[itemId];
        }
    }
    return netWorth;
}


function getProfile(discordId) {
    const userinformation = readUsers();
    const user = userinformation.mcuser[discordId];

    if (!user) {
        throw new Error('User not found. Use /minecraft start to join the game.');
    }

    const balance = user.balance || 0;
    const name = user.name;
    const pfp = user.pfplink || 'default_avatar_url'; // Default URL in case pfplink is missing
    const coords = `${user.coordinates.x}, ${user.coordinates.y}, ${user.coordinates.z}`;
    const playid = user.id;
    const biome = user.biome;
    let minestatus = user.mining.startTime ? 'Currently Mining' : 'Not Mining';
	const netWorth = calculateNetWorth(user.inventory);

    const profileEmbed = new EmbedBuilder()
        .setColor('#eeff00')
        .setTitle(`${name}'s Profile`)
        .setThumbnail(pfp)
        .addFields(
            { name: 'Balance', value: `***£${balance}***`, inline: true },
			{ name: 'NetWorth', value: `***£${netWorth}***`, inline: true },
            { name: 'Mining Status', value: `***${minestatus}***`, inline: true },
            { name: 'In Game Player ID', value: `***${playid}***`, inline: true },
            { name: '\u200B', value: '\u200B' }, // This creates an empty field for spacing
			{ name: 'Current Coords', value: `Located at ***${coords}***, in a ***${biome}*** biome.`, inline: true },
        )
        .setTimestamp();

    return profileEmbed;
}


module.exports = {
	data: new SlashCommandBuilder()
		.setName("minecraft")
		.setDescription("Minecraft Game Commands")
		.addSubcommand((subcommand) =>
			subcommand
				.setName("start")
				.setDescription("Start your Minecraft journey")
				.addStringOption((option) =>
					option
						.setName("name")
						.setDescription("Your character's name")
						.setRequired(true),
				)
				.addStringOption((option) =>
					option
						.setName("description")
						.setDescription("Description of your character"),
				),
		)
		.addSubcommand((subcommand) =>
			subcommand
				.setName("explore")
				.setDescription("Explore new biomes and structures"),
		)
		.addSubcommand((subcommand) =>
			subcommand
				.setName("profile")
				.setDescription("Have a look at what your in game profile looks like."),
		)
		.addSubcommand((subcommand) =>
			subcommand.setName("inventory").setDescription("Check your inventory"),
		)
		.addSubcommand((subcommand) =>
			subcommand
				.setName("mine")
				.setDescription("Start mining")
				.addIntegerOption((option) =>
					option
						.setName("duration")
						.setDescription("Duration of mining in seconds")
						.setRequired(true),
				),
		)
		
		.addSubcommand((subcommand) =>
			subcommand
				.setName("sell")
				.setDescription("Sell items from your inventory")
				.addStringOption((option) =>
					option
						.setName("item")
						.setDescription("The ID of the item to sell")
						.setRequired(true),
				)
				.addIntegerOption((option) =>
					option
						.setName("amount")
						.setDescription("The amount of the item to sell")
						.setRequired(true),
				),
		),
		async execute(interaction) {
			const subcommand = interaction.options.getSubcommand();
			const discordId = interaction.user.id;
		
			try {
				switch (subcommand) {
					case "start":
						const name = interaction.options.getString("name");
						const description = interaction.options.getString("description") || "";
						addUser(discordId, name, description, interaction.createdTimestamp);
						await interaction.reply(`Welcome to the Minecraft world, ${name}!`);
						break;
					case "explore":
						const exploreResult = exploreUser(discordId);
						await interaction.reply(exploreResult.message);
						break;
					case "inventory":
						const inventory = getUserInventory(discordId);
						await interaction.reply(inventory);
						break;
					case "profile":
						const userProfile = getProfile(discordId);
						await interaction.deferReply();
						await interaction.editReply({ embeds: [userProfile] });
						break;
					case "mine":
						const duration = interaction.options.getInteger("duration");
						const miningMessage = startMining(discordId, duration, interaction);
						await interaction.reply(miningMessage);
						break;
					case "sell":
						const item = interaction.options.getString("item");
						const amount = interaction.options.getInteger("amount");
						const sellMessage = sellItem(discordId, item, amount);
						await interaction.reply(sellMessage);
						break;
					default:
						await interaction.reply("Unknown command.");
						break;
				}
			} catch (error) {
				console.error(error); // Log the error for debugging
				await interaction.reply(`Error: ${error.message}`);
			}
		},
};
